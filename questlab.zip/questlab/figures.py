"""Declarative teaching diagrams, rendered to inline SVG.

A lesson section or a question carries a `figure` object such as

    {"type": "bar_chart", "categories": ["Nov", "Dec"], "values": [50, 150], "unit": "mm"}

and `render(spec)` turns it into an SVG string. Every renderer is pure, takes
only JSON-able data, and draws with the app's CSS variables so the figures
match the rest of the page. `validate_content.py` renders every figure in the
packs, so a bad spec is caught before it reaches a kid.

Supported types are the keys of RENDERERS at the bottom of the file.
"""
import math
from html import escape as _esc

# Palette — CSS variables from static/style.css, with literal fallbacks so the
# SVG also looks right if it is ever viewed on its own.
INK = "var(--ink, #17212b)"
INK2 = "var(--ink-2, #4a5b6b)"
INK3 = "var(--ink-3, #7d8fa0)"
LINE = "var(--line, #e3ded4)"
TEAL = "var(--teal, #0f8a80)"
TEAL_SOFT = "var(--teal-soft, #e2f2f0)"
AMBER = "var(--amber, #c9761a)"
AMBER_SOFT = "var(--amber-soft, #fbeedd)"
VIOLET = "var(--violet, #6b52c9)"
VIOLET_SOFT = "var(--violet-soft, #ece7fa)"
GREEN = "var(--green, #2f8f4e)"
RED = "var(--red, #c0402f)"
CARD = "var(--card, #ffffff)"
SERIES = [TEAL, AMBER, VIOLET, GREEN, RED]

FONT = 'font-family="ui-sans-serif,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif"'


class FigureError(ValueError):
    pass


def esc(text):
    return _esc(str(text), quote=True)


def _num(value, name):
    try:
        return float(value)
    except (TypeError, ValueError):
        raise FigureError(f"{name} must be a number, got {value!r}")


def _fmt(value):
    value = float(value)
    return str(int(value)) if value == int(value) else f"{value:g}"


def svg(width, height, body, caption=None, cls=""):
    """Wrap a body in a responsive <svg>."""
    label = f' role="img" aria-label="{esc(caption)}"' if caption else ' role="img"'
    out = (f'<svg class="fig {cls}" viewBox="0 0 {width} {height}" '
           f'width="{width}" style="max-width:100%;height:auto" {FONT}{label}>'
           f'{body}</svg>')
    if caption:
        out += f'<figcaption>{esc(caption)}</figcaption>'
    return f'<figure class="figure">{out}</figure>'


def text(x, y, s, size=13, anchor="middle", fill=INK, weight="", extra=""):
    w = f' font-weight="{weight}"' if weight else ""
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" '
            f'fill="{fill}"{w} {extra}>{esc(s)}</text>')


# --------------------------------------------------------------------------
# number and fraction figures
# --------------------------------------------------------------------------
def fraction_bar(spec):
    """One or more bars split into equal parts with some shaded.

    {"parts": 8, "shaded": 3, "label": "3/8"}
    {"bars": [{"parts": 4, "shaded": 1, "label": "1/4"}, {"parts": 8, "shaded": 2, "label": "2/8"}]}
    """
    bars = spec.get("bars") or [spec]
    W, H, gap = 420, 44, 26
    body = []
    for i, bar in enumerate(bars):
        parts = int(_num(bar.get("parts", 1), "parts"))
        shaded = _num(bar.get("shaded", 0), "shaded")
        if parts < 1:
            raise FigureError("parts must be at least 1")
        y = 10 + i * (H + gap)
        pw = W / parts
        colour = SERIES[i % len(SERIES)]
        for p in range(parts):
            fill = colour if p < shaded else CARD
            if shaded - p == 0.5:                      # half a part shaded
                body.append(f'<rect x="{20 + p*pw:.1f}" y="{y}" width="{pw/2:.1f}" height="{H}" fill="{colour}"/>')
                fill = CARD
            body.append(f'<rect x="{20 + p*pw:.1f}" y="{y}" width="{pw:.1f}" height="{H}" '
                        f'fill="{fill}" stroke="{INK}" stroke-width="1.5" fill-opacity="{0.85 if p < shaded else 1}"/>')
        if bar.get("label"):
            body.append(text(20 + W + 12, y + H / 2 + 5, bar["label"], 15, "start", weight="700"))
    height = 10 + len(bars) * (H + gap) - gap + 10
    return svg(W + 120, height, "".join(body), spec.get("caption"))


def number_line(spec):
    """{"min": 0, "max": 2, "step": 0.5, "marks": [{"at": 1.3, "label": "1.3"}], "range": [0.5, 1]}"""
    lo, hi = _num(spec.get("min", 0), "min"), _num(spec.get("max", 10), "max")
    if hi <= lo:
        raise FigureError("max must be greater than min")
    step = _num(spec.get("step", 1), "step")
    minor = spec.get("minor")              # optional finer tick spacing
    W, H, pad = 520, 90, 30
    scale = (W - 2 * pad) / (hi - lo)
    X = lambda v: pad + (v - lo) * scale
    y = 52
    body = [f'<line x1="{pad-8}" y1="{y}" x2="{W-pad+8}" y2="{y}" stroke="{INK}" stroke-width="2"/>']
    if spec.get("range"):
        a, b = spec["range"]
        body.append(f'<rect x="{X(a):.1f}" y="{y-14}" width="{X(b)-X(a):.1f}" height="28" fill="{TEAL_SOFT}" rx="4"/>')
    if minor:
        v = lo
        while v <= hi + 1e-9:
            body.append(f'<line x1="{X(v):.1f}" y1="{y-5}" x2="{X(v):.1f}" y2="{y+5}" stroke="{INK3}" stroke-width="1"/>')
            v += _num(minor, "minor")
    v = lo
    n = 0
    while v <= hi + 1e-9 and n < 200:
        body.append(f'<line x1="{X(v):.1f}" y1="{y-10}" x2="{X(v):.1f}" y2="{y+10}" stroke="{INK}" stroke-width="2"/>')
        body.append(text(X(v), y + 28, _fmt(v), 13, fill=INK2))
        v += step
        n += 1
    for i, m in enumerate(spec.get("marks", [])):
        at = _num(m.get("at"), "mark at")
        colour = m.get("colour") or SERIES[i % len(SERIES)]
        body.append(f'<circle cx="{X(at):.1f}" cy="{y}" r="7" fill="{colour}" stroke="{CARD}" stroke-width="2"/>')
        if m.get("label"):
            body.append(text(X(at), y - 20, m["label"], 14, weight="700", fill=colour))
    return svg(W, H, "".join(body), spec.get("caption"))


def area_grid(spec):
    """{"width": 6, "height": 4, "unit": "m", "shade": 15}  (shade = number of squares to fill)"""
    w, h = int(_num(spec.get("width", 5), "width")), int(_num(spec.get("height", 3), "height"))
    if not (1 <= w <= 30 and 1 <= h <= 20):
        raise FigureError("area_grid width 1-30, height 1-20")
    cell = min(40, 440 / w, 300 / h)
    unit = spec.get("unit", "")
    shade = int(_num(spec.get("shade", w * h if spec.get("filled", True) else 0), "shade"))
    ox, oy = 40, 20
    body = []
    k = 0
    for r in range(h):
        for c in range(w):
            fill = TEAL_SOFT if k < shade else CARD
            body.append(f'<rect x="{ox + c*cell:.1f}" y="{oy + r*cell:.1f}" width="{cell:.1f}" height="{cell:.1f}" '
                        f'fill="{fill}" stroke="{INK2}" stroke-width="1"/>')
            k += 1
    body.append(text(ox + w * cell / 2, oy + h * cell + 24, f"{w} {unit}".strip(), 14, weight="700"))
    body.append(text(ox - 12, oy + h * cell / 2 + 5, f"{h} {unit}".strip(), 14, "end", weight="700"))
    return svg(ox + w * cell + 30, oy + h * cell + 40, "".join(body), spec.get("caption"))


def rectangle(spec):
    """A labelled shape with dimension arrows. {"width": "12 m", "height": "5 m", "shape": "rectangle"}"""
    wl, hl = str(spec.get("width", "")), str(spec.get("height", ""))
    try:
        ratio = float(str(wl).split()[0]) / float(str(hl).split()[0])
    except (ValueError, IndexError, ZeroDivisionError):
        ratio = 1.6
    ratio = max(0.5, min(3.0, ratio))
    W = 300
    Hh = W / ratio
    ox, oy = 90, 24
    body = [f'<rect x="{ox}" y="{oy}" width="{W}" height="{Hh:.1f}" fill="{TEAL_SOFT}" stroke="{INK}" stroke-width="2" rx="2"/>']
    # dimension lines
    yb = oy + Hh + 22
    body.append(f'<line x1="{ox}" y1="{yb}" x2="{ox+W}" y2="{yb}" stroke="{INK2}" stroke-width="1.5" marker-start="url(#dimA)" marker-end="url(#dimB)"/>')
    body.append(text(ox + W / 2, yb + 18, wl, 14, weight="700"))
    xl = ox - 18
    body.append(f'<line x1="{xl}" y1="{oy}" x2="{xl}" y2="{oy+Hh:.1f}" stroke="{INK2}" stroke-width="1.5"/>')
    body.append(text(xl - 6, oy + Hh / 2 + 5, hl, 14, "end", weight="700"))
    if spec.get("inner"):
        body.append(text(ox + W / 2, oy + Hh / 2 + 5, spec["inner"], 15, fill=INK2))
    return svg(W + 130, yb + 34, "".join(body), spec.get("caption"))


# --------------------------------------------------------------------------
# data displays
# --------------------------------------------------------------------------
def bar_chart(spec):
    """{"categories": [...], "values": [...], "unit": "mm", "grid": 50, "ymin": 0, "title": "...", "highlight": 2}

    ymin > 0 draws a chopped axis (for the misleading-graph lessons).
    """
    cats, vals = spec.get("categories") or [], spec.get("values") or []
    if not cats or len(cats) != len(vals):
        raise FigureError("bar_chart needs categories and values of the same length")
    vals = [_num(v, "value") for v in vals]
    ymin = _num(spec.get("ymin", 0), "ymin")
    grid = _num(spec.get("grid", 0), "grid") or None
    top = _num(spec.get("ymax", 0), "ymax") or max(vals) * 1.15
    if grid:
        top = math.ceil(top / grid) * grid
    if top <= ymin:
        raise FigureError("bar_chart ymax must exceed ymin")
    W, H = 520, 300
    L, R, T, B = 64, 20, 40 if spec.get("title") else 20, 50
    pw, ph = W - L - R, H - T - B
    Y = lambda v: T + ph - (v - ymin) / (top - ymin) * ph
    body = []
    if spec.get("title"):
        body.append(text(L + pw / 2, 24, spec["title"], 15, weight="700"))
    # gridlines
    g = grid or (top - ymin) / 5
    v = ymin
    while v <= top + 1e-9:
        body.append(f'<line x1="{L}" y1="{Y(v):.1f}" x2="{L+pw}" y2="{Y(v):.1f}" stroke="{LINE}" stroke-width="1"/>')
        body.append(text(L - 8, Y(v) + 4, _fmt(v), 12, "end", INK2))
        v += g
    if spec.get("unit"):
        body.append(text(14, T - 6 if T > 20 else 12, spec["unit"], 12, "start", INK3))
    # chopped axis marker
    if ymin > 0:
        body.append(f'<path d="M{L-3},{T+ph-6} l6,-4 l-6,-4 l6,-4" fill="none" stroke="{RED}" stroke-width="2"/>')
    bw = pw / len(cats)
    hi = spec.get("highlight")
    for i, (c, v) in enumerate(zip(cats, vals)):
        x = L + i * bw + bw * 0.18
        w = bw * 0.64
        colour = AMBER if (hi is not None and i == hi) else TEAL
        yv = Y(max(v, ymin))
        body.append(f'<rect x="{x:.1f}" y="{yv:.1f}" width="{w:.1f}" height="{T+ph-yv:.1f}" fill="{colour}" rx="3"/>')
        if spec.get("show_values"):
            body.append(text(x + w / 2, yv - 6, _fmt(v), 12, weight="700"))
        body.append(text(x + w / 2, T + ph + 20, c, 12, fill=INK2))
    body.append(f'<line x1="{L}" y1="{T}" x2="{L}" y2="{T+ph}" stroke="{INK}" stroke-width="1.5"/>')
    body.append(f'<line x1="{L}" y1="{T+ph}" x2="{L+pw}" y2="{T+ph}" stroke="{INK}" stroke-width="1.5"/>')
    if spec.get("xlabel"):
        body.append(text(L + pw / 2, H - 8, spec["xlabel"], 12, fill=INK3))
    return svg(W, H, "".join(body), spec.get("caption"))


def line_chart(spec):
    """{"x": ["Mon", ...], "series": [{"name": "Sun", "values": [...]}, ...], "unit": "°C", "grid": 5}"""
    xs = spec.get("x") or []
    series = spec.get("series") or ([{"name": "", "values": spec.get("values", [])}] if spec.get("values") else [])
    if not xs or not series:
        raise FigureError("line_chart needs x and series/values")
    allv = [_num(v, "value") for s in series for v in s["values"]]
    ymin = _num(spec.get("ymin", min(0, min(allv))), "ymin")
    top = _num(spec.get("ymax", 0), "ymax") or max(allv) * 1.15
    grid = _num(spec.get("grid", 0), "grid") or (top - ymin) / 5
    top = math.ceil(top / grid) * grid
    W, H = 520, 300
    L, R, T, B = 60, 20, 40 if spec.get("title") else 24, 50
    pw, ph = W - L - R, H - T - B
    X = lambda i: L + (i / max(1, len(xs) - 1)) * pw
    Y = lambda v: T + ph - (v - ymin) / (top - ymin) * ph
    body = []
    if spec.get("title"):
        body.append(text(L + pw / 2, 24, spec["title"], 15, weight="700"))
    v = ymin
    while v <= top + 1e-9:
        body.append(f'<line x1="{L}" y1="{Y(v):.1f}" x2="{L+pw}" y2="{Y(v):.1f}" stroke="{LINE}"/>')
        body.append(text(L - 8, Y(v) + 4, _fmt(v), 12, "end", INK2))
        v += grid
    for i, lab in enumerate(xs):
        body.append(text(X(i), T + ph + 20, lab, 12, fill=INK2))
    for si, s in enumerate(series):
        vals = [_num(v, "value") for v in s["values"]]
        if len(vals) != len(xs):
            raise FigureError("each series needs one value per x")
        colour = SERIES[si % len(SERIES)]
        pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(vals))
        body.append(f'<polyline points="{pts}" fill="none" stroke="{colour}" stroke-width="3" stroke-linejoin="round"/>')
        for i, val in enumerate(vals):
            body.append(f'<circle cx="{X(i):.1f}" cy="{Y(val):.1f}" r="4.5" fill="{colour}" stroke="{CARD}" stroke-width="2"/>')
        if s.get("name"):
            body.append(f'<rect x="{L + 10 + si*110}" y="{H-14}" width="14" height="4" fill="{colour}"/>')
            body.append(text(L + 30 + si * 110, H - 9, s["name"], 12, "start", INK2))
    body.append(f'<line x1="{L}" y1="{T}" x2="{L}" y2="{T+ph}" stroke="{INK}" stroke-width="1.5"/>')
    body.append(f'<line x1="{L}" y1="{T+ph}" x2="{L+pw}" y2="{T+ph}" stroke="{INK}" stroke-width="1.5"/>')
    if spec.get("unit"):
        body.append(text(12, 14, spec["unit"], 12, "start", INK3))
    return svg(W, H, "".join(body), spec.get("caption"))


def picture_graph(spec):
    """{"symbol": "🥭", "each": 4, "rows": [{"label": "Mon", "count": 3.5}]}  count = number of symbols"""
    rows = spec.get("rows") or []
    if not rows:
        raise FigureError("picture_graph needs rows")
    sym = spec.get("symbol", "●")
    each = spec.get("each")
    rh, lw, sw = 38, 90, 30
    maxn = max(_num(r.get("count", 0), "count") for r in rows)
    W = lw + int(math.ceil(maxn)) * sw + 30
    H = 16 + len(rows) * rh + (30 if each else 8)
    body = []
    for i, r in enumerate(rows):
        y = 16 + i * rh
        body.append(text(lw - 12, y + 25, r.get("label", ""), 14, "end", weight="700"))
        n = _num(r.get("count", 0), "count")
        k = 0
        while k < int(n):
            body.append(f'<text x="{lw + k*sw}" y="{y+27}" font-size="22">{esc(sym)}</text>')
            k += 1
        if n - int(n) >= 0.5:
            # half a symbol: clip the right half away
            cid = f"half{i}"
            body.append(f'<clipPath id="{cid}"><rect x="{lw + k*sw}" y="{y}" width="13" height="{rh}"/></clipPath>')
            body.append(f'<text x="{lw + k*sw}" y="{y+27}" font-size="22" clip-path="url(#{cid})">{esc(sym)}</text>')
        body.append(f'<line x1="{lw-6}" y1="{y+rh-4}" x2="{W-10}" y2="{y+rh-4}" stroke="{LINE}"/>')
    if each:
        body.append(f'<rect x="{lw-6}" y="{H-26}" width="{W-lw-4}" height="22" fill="{AMBER_SOFT}" rx="6"/>')
        body.append(f'<text x="{lw+2}" y="{H-10}" font-size="15">{esc(sym)}</text>')
        body.append(text(lw + 28, H - 10, f"= {each}", 13, "start", weight="700"))
    return svg(W, H, "".join(body), spec.get("caption"))


def tally(spec):
    """{"rows": [{"label": "Cassowary", "count": 7}]}"""
    rows = spec.get("rows") or []
    if not rows:
        raise FigureError("tally needs rows")
    rh, lw = 36, 120
    W, H = 460, 12 + len(rows) * rh
    body = []
    for i, r in enumerate(rows):
        y = 12 + i * rh
        n = int(_num(r.get("count", 0), "count"))
        body.append(text(lw - 12, y + 24, r.get("label", ""), 14, "end", weight="700"))
        x = lw
        for g in range(n // 5):
            for k in range(4):
                body.append(f'<line x1="{x+k*7}" y1="{y+6}" x2="{x+k*7}" y2="{y+30}" stroke="{INK}" stroke-width="2"/>')
            body.append(f'<line x1="{x-3}" y1="{y+26}" x2="{x+25}" y2="{y+10}" stroke="{AMBER}" stroke-width="2.5"/>')
            x += 40
        for k in range(n % 5):
            body.append(f'<line x1="{x+k*7}" y1="{y+6}" x2="{x+k*7}" y2="{y+30}" stroke="{INK}" stroke-width="2"/>')
        if spec.get("show_totals", True):
            body.append(text(W - 12, y + 24, str(n), 14, "end", INK2))
        body.append(f'<line x1="{lw-6}" y1="{y+rh-2}" x2="{W-8}" y2="{y+rh-2}" stroke="{LINE}"/>')
    return svg(W, H, "".join(body), spec.get("caption"))


def table(spec):
    """{"headers": ["Item", "Price"], "rows": [["Mango", "$2.50"], ...], "highlight": 1}"""
    headers, rows = spec.get("headers") or [], spec.get("rows") or []
    if not headers or not rows:
        raise FigureError("table needs headers and rows")
    cols = len(headers)
    cw = max(90, min(200, 520 // cols))
    rh = 32
    W, H = cw * cols + 2, rh * (len(rows) + 1) + 2
    body = [f'<rect x="1" y="1" width="{W-2}" height="{rh}" fill="{TEAL_SOFT}"/>']
    for j, h in enumerate(headers):
        body.append(text(1 + j * cw + 10, 22, h, 13, "start", weight="700"))
    for i, r in enumerate(rows):
        if len(r) != cols:
            raise FigureError("every table row needs one cell per header")
        y = 1 + (i + 1) * rh
        if spec.get("highlight") == i:
            body.append(f'<rect x="1" y="{y}" width="{W-2}" height="{rh}" fill="{AMBER_SOFT}"/>')
        for j, cell in enumerate(r):
            body.append(text(1 + j * cw + 10, y + 21, cell, 13, "start"))
        body.append(f'<line x1="1" y1="{y}" x2="{W-1}" y2="{y}" stroke="{LINE}"/>')
    body.append(f'<rect x="1" y="1" width="{W-2}" height="{H-2}" fill="none" stroke="{INK2}" rx="4"/>')
    return svg(W, H, "".join(body), spec.get("caption"))


def spinner(spec):
    """{"sectors": [{"label": "red", "n": 3, "colour": "#c0402f"}, {"label": "blue", "n": 1}]}"""
    sectors = spec.get("sectors") or []
    total = sum(_num(s.get("n", 1), "n") for s in sectors)
    if not sectors or total <= 0:
        raise FigureError("spinner needs sectors")
    cx, cy, r = 130, 130, 110
    body = []
    a = -90.0
    for i, s in enumerate(sectors):
        sweep = 360 * _num(s.get("n", 1), "n") / total
        a2 = a + sweep
        x1, y1 = cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a))
        x2, y2 = cx + r * math.cos(math.radians(a2)), cy + r * math.sin(math.radians(a2))
        large = 1 if sweep > 180 else 0
        colour = s.get("colour") or SERIES[i % len(SERIES)]
        body.append(f'<path d="M{cx},{cy} L{x1:.1f},{y1:.1f} A{r},{r} 0 {large} 1 {x2:.1f},{y2:.1f} Z" '
                    f'fill="{colour}" fill-opacity="0.8" stroke="{CARD}" stroke-width="2"/>')
        mid = math.radians((a + a2) / 2)
        body.append(text(cx + r * 0.62 * math.cos(mid), cy + r * 0.62 * math.sin(mid) + 5,
                         s.get("label", ""), 13, weight="700", fill=CARD))
        a = a2
    body.append(f'<polygon points="{cx},{cy-r-14} {cx-9},{cy-r+6} {cx+9},{cy-r+6}" fill="{INK}"/>')
    body.append(f'<circle cx="{cx}" cy="{cy}" r="6" fill="{INK}"/>')
    return svg(260, 260, "".join(body), spec.get("caption"))


# --------------------------------------------------------------------------
# measurement
# --------------------------------------------------------------------------
def angle(spec):
    """{"degrees": 60, "protractor": true, "label": "?"}"""
    deg = _num(spec.get("degrees", 45), "degrees")
    if not 0 < deg < 360:
        raise FigureError("degrees must be between 0 and 360")
    cx, cy, r = 200, 190, 150
    body = []
    if spec.get("protractor", True) and deg <= 180:
        body.append(f'<path d="M{cx-r},{cy} A{r},{r} 0 0 1 {cx+r},{cy} Z" fill="{VIOLET_SOFT}" stroke="{INK2}" stroke-width="1.5"/>')
        for d in range(0, 181, 10):
            a = math.radians(180 - d)
            inner = r - (16 if d % 30 == 0 else 8)
            body.append(f'<line x1="{cx + inner*math.cos(a):.1f}" y1="{cy - inner*math.sin(a):.1f}" '
                        f'x2="{cx + r*math.cos(a):.1f}" y2="{cy - r*math.sin(a):.1f}" stroke="{INK2}" stroke-width="1"/>')
            if d % 30 == 0:
                body.append(text(cx + (r - 28) * math.cos(a), cy - (r - 28) * math.sin(a) + 4, str(d), 11, fill=INK2))
    # the angle itself
    a = math.radians(deg)
    arm = 120
    body.append(f'<path d="M{cx+34},{cy} A34,34 0 {1 if deg > 180 else 0} 0 {cx + 34*math.cos(a):.1f},{cy - 34*math.sin(a):.1f}" '
                f'fill="none" stroke="{AMBER}" stroke-width="3"/>')
    body.append(f'<line x1="{cx}" y1="{cy}" x2="{cx+arm}" y2="{cy}" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>')
    body.append(f'<line x1="{cx}" y1="{cy}" x2="{cx + arm*math.cos(a):.1f}" y2="{cy - arm*math.sin(a):.1f}" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>')
    body.append(f'<circle cx="{cx}" cy="{cy}" r="4" fill="{INK}"/>')
    label = spec.get("label", f"{_fmt(deg)}°")
    mid = math.radians(deg / 2)
    body.append(text(cx + 58 * math.cos(mid), cy - 58 * math.sin(mid) + 5, label, 15, weight="700", fill=AMBER))
    return svg(400, 220, "".join(body), spec.get("caption"))


def clock(spec):
    """{"time": "3:45", "digital": true}"""
    t = str(spec.get("time", "3:00"))
    try:
        hh, mm = [int(p) for p in t.split(":")[:2]]
    except ValueError:
        raise FigureError("clock time must look like 3:45")
    cx, cy, r = 110, 110, 96
    body = [f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{CARD}" stroke="{INK}" stroke-width="3"/>']
    for i in range(60):
        a = math.radians(i * 6 - 90)
        inner = r - (12 if i % 5 == 0 else 5)
        body.append(f'<line x1="{cx+inner*math.cos(a):.1f}" y1="{cy+inner*math.sin(a):.1f}" '
                    f'x2="{cx+(r-2)*math.cos(a):.1f}" y2="{cy+(r-2)*math.sin(a):.1f}" stroke="{INK2}" stroke-width="{2 if i%5==0 else 1}"/>')
    for h in range(1, 13):
        a = math.radians(h * 30 - 90)
        body.append(text(cx + (r - 26) * math.cos(a), cy + (r - 26) * math.sin(a) + 5, str(h), 14, weight="700"))
    ha = math.radians((hh % 12) * 30 + mm * 0.5 - 90)
    ma = math.radians(mm * 6 - 90)
    body.append(f'<line x1="{cx}" y1="{cy}" x2="{cx+52*math.cos(ha):.1f}" y2="{cy+52*math.sin(ha):.1f}" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>')
    body.append(f'<line x1="{cx}" y1="{cy}" x2="{cx+76*math.cos(ma):.1f}" y2="{cy+76*math.sin(ma):.1f}" stroke="{AMBER}" stroke-width="4" stroke-linecap="round"/>')
    body.append(f'<circle cx="{cx}" cy="{cy}" r="5" fill="{INK}"/>')
    if spec.get("digital"):
        body.append(text(cx, 236, f"{hh}:{mm:02d}", 18, weight="700"))
    return svg(220, 250 if spec.get("digital") else 222, "".join(body), spec.get("caption"))


def thermometer(spec):
    """{"min": -10, "max": 50, "value": 31, "unit": "°C", "step": 10}"""
    lo, hi = _num(spec.get("min", 0), "min"), _num(spec.get("max", 50), "max")
    val = _num(spec.get("value", lo), "value")
    step = _num(spec.get("step", 10), "step")
    if hi <= lo or not lo <= val <= hi:
        raise FigureError("thermometer value must sit between min and max")
    x, top, bottom = 70, 20, 250
    Y = lambda v: bottom - (v - lo) / (hi - lo) * (bottom - top)
    body = [f'<rect x="{x-12}" y="{top-8}" width="24" height="{bottom-top+16}" rx="12" fill="{CARD}" stroke="{INK}" stroke-width="2"/>',
            f'<rect x="{x-6}" y="{Y(val):.1f}" width="12" height="{bottom-Y(val)+2:.1f}" fill="{RED}"/>',
            f'<circle cx="{x}" cy="{bottom+16}" r="18" fill="{RED}" stroke="{INK}" stroke-width="2"/>']
    v = lo
    while v <= hi + 1e-9:
        body.append(f'<line x1="{x+14}" y1="{Y(v):.1f}" x2="{x+24}" y2="{Y(v):.1f}" stroke="{INK}" stroke-width="1.5"/>')
        body.append(text(x + 30, Y(v) + 4, f"{_fmt(v)}{spec.get('unit','')}", 12, "start", INK2))
        v += step
    body.append(text(x + 46, Y(val) + 4, f"← {_fmt(val)}{spec.get('unit','')}", 14, "start", weight="700", fill=RED))
    return svg(200, 300, "".join(body), spec.get("caption"))


def coins(spec):
    """Australian money laid out. {"items": [2, 1, 0.5, 0.2, 0.1, 0.05, 5, 10, 20, 50, 100]}"""
    items = spec.get("items") or []
    if not items:
        raise FigureError("coins needs items")
    body, x = [], 10
    coin_r = {2: 20, 1: 24, 0.5: 28, 0.2: 26, 0.1: 22, 0.05: 18}
    note_col = {5: "#c26aa8", 10: "#3b7ac2", 20: "#c2452b", 50: "#c9a11a", 100: "#3a9a5a"}
    for v in items:
        v = _num(v, "item")
        if v in coin_r:
            r = coin_r[v]
            gold = v in (2, 1)
            body.append(f'<circle cx="{x+r}" cy="46" r="{r}" fill="{"#d9b34a" if gold else "#c9cfd6"}" stroke="{INK2}" stroke-width="1.5"/>')
            lab = f"${_fmt(v)}" if v >= 1 else f"{int(v*100)}c"
            body.append(text(x + r, 51, lab, 12, weight="700"))
            x += 2 * r + 12
        elif v in note_col:
            body.append(f'<rect x="{x}" y="22" width="76" height="46" rx="5" fill="{note_col[v]}" fill-opacity="0.85" stroke="{INK2}"/>')
            body.append(text(x + 38, 51, f"${int(v)}", 15, weight="700", fill=CARD))
            x += 88
        else:
            raise FigureError(f"unknown Australian coin or note: {v}")
    return svg(x + 10, 92, "".join(body), spec.get("caption"))


# --------------------------------------------------------------------------
# space & coordinates
# --------------------------------------------------------------------------
def cartesian(spec):
    """{"range": 5, "points": [{"x": 2, "y": -3, "label": "A"}], "quadrants": 4}"""
    rng = int(_num(spec.get("range", 5), "range"))
    quads = int(spec.get("quadrants", 4))
    size = 320
    if quads == 1:
        lo_x = lo_y = 0
    else:
        lo_x = lo_y = -rng
    n = rng - lo_x
    cell = size / n
    ox, oy = 30, 10
    X = lambda v: ox + (v - lo_x) * cell
    Y = lambda v: oy + (rng - v) * cell
    body = []
    for i in range(n + 1):
        v = lo_x + i
        body.append(f'<line x1="{X(v):.1f}" y1="{oy}" x2="{X(v):.1f}" y2="{oy+size}" stroke="{LINE}"/>')
        body.append(f'<line x1="{ox}" y1="{Y(v):.1f}" x2="{ox+size}" y2="{Y(v):.1f}" stroke="{LINE}"/>')
        if v != 0:
            body.append(text(X(v), Y(0) + 14, str(v), 10, fill=INK3))
            body.append(text(X(0) - 6, Y(v) + 3, str(v), 10, "end", INK3))
    body.append(f'<line x1="{ox}" y1="{Y(0):.1f}" x2="{ox+size}" y2="{Y(0):.1f}" stroke="{INK}" stroke-width="1.5"/>')
    body.append(f'<line x1="{X(0):.1f}" y1="{oy}" x2="{X(0):.1f}" y2="{oy+size}" stroke="{INK}" stroke-width="1.5"/>')
    body.append(text(ox + size + 8, Y(0) + 4, "x", 13, "start", weight="700"))
    body.append(text(X(0), oy - 2, "y", 13, weight="700"))
    for i, p in enumerate(spec.get("points", [])):
        px, py = _num(p.get("x"), "x"), _num(p.get("y"), "y")
        colour = SERIES[i % len(SERIES)]
        body.append(f'<circle cx="{X(px):.1f}" cy="{Y(py):.1f}" r="6" fill="{colour}" stroke="{CARD}" stroke-width="2"/>')
        if p.get("label"):
            body.append(text(X(px) + 9, Y(py) - 8, p["label"], 13, "start", weight="700", fill=colour))
    if spec.get("segments"):
        for seg in spec["segments"]:
            (x1, y1), (x2, y2) = seg
            body.append(f'<line x1="{X(x1):.1f}" y1="{Y(y1):.1f}" x2="{X(x2):.1f}" y2="{Y(y2):.1f}" stroke="{TEAL}" stroke-width="2"/>')
    return svg(size + 60, size + 30, "".join(body), spec.get("caption"))


# --------------------------------------------------------------------------
# science
# --------------------------------------------------------------------------
def _bulb(x, y, on, label=""):
    glow = f'<circle cx="{x}" cy="{y}" r="22" fill="{AMBER}" fill-opacity="0.25"/>' if on else ""
    return (glow + f'<circle cx="{x}" cy="{y}" r="14" fill="{"#ffd54a" if on else CARD}" stroke="{INK}" stroke-width="2"/>'
            f'<path d="M{x-6},{y+4} l4,-6 l4,6 l4,-6" fill="none" stroke="{INK}" stroke-width="1.5"/>'
            + (text(x, y + 34, label, 11, fill=INK2) if label else ""))


def circuit(spec):
    """{"bulbs": 2, "switch": "closed"|"open"|null, "battery": true, "broken": false, "series": true, "labels": true}

    Draws a simple loop: battery on the left, bulbs along the top, optional switch on the right.
    Bulbs are lit only if the loop is complete.
    """
    n = int(_num(spec.get("bulbs", 1), "bulbs"))
    if not 0 <= n <= 4:
        raise FigureError("circuit supports 0-4 bulbs")
    sw = spec.get("switch")
    parallel = not spec.get("series", True) and n > 1
    complete = spec.get("battery", True) and sw != "open" and not spec.get("broken")
    W, H = 460, 230
    L, R, T, B = 60, 400, 50, 180
    body = []
    stroke = f'stroke="{INK}" stroke-width="3" fill="none"'
    # battery (left side)
    if spec.get("battery", True):
        body.append(f'<line x1="{L}" y1="{T}" x2="{L}" y2="{105}" {stroke}/>')
        body.append(f'<line x1="{L-16}" y1="105" x2="{L+16}" y2="105" {stroke}/>')
        body.append(f'<line x1="{L-8}" y1="115" x2="{L+8}" y2="115" {stroke}/>')
        body.append(f'<line x1="{L-16}" y1="125" x2="{L+16}" y2="125" {stroke}/>')
        body.append(f'<line x1="{L-8}" y1="135" x2="{L+8}" y2="135" {stroke}/>')
        body.append(f'<line x1="{L}" y1="135" x2="{L}" y2="{B}" {stroke}/>')
        body.append(text(L - 22, 100, "+", 14, "end", weight="700"))
        if spec.get("labels", True):
            body.append(text(L, B + 26, "battery", 11, fill=INK2))
    else:
        body.append(f'<line x1="{L}" y1="{T}" x2="{L}" y2="{B}" stroke="{RED}" stroke-width="3" stroke-dasharray="6 6"/>')
    # top wire with bulbs (series) or branches (parallel)
    if parallel:
        body.append(f'<line x1="{L}" y1="{T}" x2="{R}" y2="{T}" {stroke}/>')
        body.append(f'<line x1="{L}" y1="{B}" x2="{R}" y2="{B}" {stroke}/>')
        for i in range(n):
            x = L + (i + 1) * (R - L) / (n + 1)
            body.append(f'<line x1="{x:.1f}" y1="{T}" x2="{x:.1f}" y2="{B}" {stroke}/>')
            body.append(_bulb(x, (T + B) / 2, complete))
            if spec.get("labels", True):
                body.append(text(x + 22, (T + B) / 2 + 4, f"bulb {i+1}", 11, "start", INK2))
    else:
        body.append(f'<line x1="{L}" y1="{T}" x2="{R}" y2="{T}" {stroke}/>')
        body.append(f'<line x1="{L}" y1="{B}" x2="{R}" y2="{B}" {stroke}/>')
        for i in range(n):
            x = L + (i + 1) * (R - L) / (n + 1)
            body.append(f'<circle cx="{x:.1f}" cy="{T}" r="16" fill="{CARD}"/>')
            body.append(_bulb(x, T, complete, f"bulb {i+1}" if spec.get("labels", True) else ""))
    # right side: switch or wire
    if sw:
        body.append(f'<line x1="{R}" y1="{T}" x2="{R}" y2="{95}" {stroke}/>')
        body.append(f'<line x1="{R}" y1="{135}" x2="{R}" y2="{B}" {stroke}/>')
        body.append(f'<circle cx="{R}" cy="95" r="4" fill="{INK}"/><circle cx="{R}" cy="135" r="4" fill="{INK}"/>')
        if sw == "open":
            body.append(f'<line x1="{R}" y1="135" x2="{R+26}" y2="103" {stroke}/>')
            body.append(text(R + 30, 124, "open", 11, "start", fill=RED))
        else:
            body.append(f'<line x1="{R}" y1="135" x2="{R}" y2="95" {stroke}/>')
            body.append(text(R + 12, 120, "closed", 11, "start", fill=GREEN))
    else:
        body.append(f'<line x1="{R}" y1="{T}" x2="{R}" y2="{B}" {stroke}/>')
    if spec.get("broken"):
        bx = (L + R) / 2
        body.append(f'<rect x="{bx-14}" y="{B-8}" width="28" height="16" fill="{CARD}"/>')
        body.append(text(bx, B + 24, "break", 11, fill=RED))
    return svg(W, H, "".join(body), spec.get("caption"))


def food_chain(spec):
    """{"items": ["grass", "grasshopper", "frog", "snake"], "roles": ["producer", "consumer", ...]}"""
    items = spec.get("items") or []
    if len(items) < 2:
        raise FigureError("food_chain needs at least two items")
    roles = spec.get("roles") or []
    bw, gap = 110, 46
    W = 20 + len(items) * (bw + gap) - gap + 20
    body = []
    for i, name in enumerate(items):
        x = 20 + i * (bw + gap)
        colour = [GREEN, TEAL, AMBER, VIOLET, RED][min(i, 4)]
        body.append(f'<rect x="{x}" y="30" width="{bw}" height="56" rx="12" fill="{colour}" fill-opacity="0.15" stroke="{colour}" stroke-width="2"/>')
        body.append(text(x + bw / 2, 63, name, 14, weight="700"))
        if i < len(roles):
            body.append(text(x + bw / 2, 106, roles[i], 11, fill=INK2))
        if i < len(items) - 1:
            ax = x + bw + 6
            body.append(f'<line x1="{ax}" y1="58" x2="{ax+gap-14}" y2="58" stroke="{INK}" stroke-width="2.5"/>')
            body.append(f'<polygon points="{ax+gap-14},51 {ax+gap-2},58 {ax+gap-14},65" fill="{INK}"/>')
    if spec.get("note"):
        body.append(text(W / 2, 134, spec["note"], 12, fill=INK3))
    return svg(W, 140 if spec.get("note") else 118, "".join(body), spec.get("caption"))


def food_web(spec):
    """{"nodes": ["sun","grass","wallaby","dingo","insects","frog"], "links": [["grass","wallaby"], ...]}"""
    nodes = spec.get("nodes") or []
    links = spec.get("links") or []
    if len(nodes) < 3:
        raise FigureError("food_web needs at least three nodes")
    cx, cy, r = 220, 170, 130
    pos = {}
    for i, n in enumerate(nodes):
        a = math.radians(-90 + i * 360 / len(nodes))
        pos[n] = (cx + r * math.cos(a), cy + r * math.sin(a))
    body = ['<defs><marker id="fwArrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
            f'<path d="M0,0 L10,5 L0,10 z" fill="{INK2}"/></marker></defs>']
    for a, b in links:
        if a not in pos or b not in pos:
            raise FigureError(f"food_web link refers to unknown node: {a} -> {b}")
        (x1, y1), (x2, y2) = pos[a], pos[b]
        dx, dy = x2 - x1, y2 - y1
        d = math.hypot(dx, dy) or 1
        x1, y1 = x1 + dx / d * 36, y1 + dy / d * 36
        x2, y2 = x2 - dx / d * 40, y2 - dy / d * 40
        body.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{INK2}" stroke-width="2" marker-end="url(#fwArrow)"/>')
    for i, n in enumerate(nodes):
        x, y = pos[n]
        colour = SERIES[i % len(SERIES)]
        body.append(f'<rect x="{x-44:.1f}" y="{y-16:.1f}" width="88" height="32" rx="16" fill="{CARD}" stroke="{colour}" stroke-width="2"/>')
        body.append(text(x, y + 5, n, 12, weight="700"))
    return svg(440, 340, "".join(body), spec.get("caption"))


def moon_phases(spec):
    """{"phase": "first quarter"}  or  {"all": true}  — the Sun is off to the right."""
    phases = ["new", "waxing crescent", "first quarter", "waxing gibbous",
              "full", "waning gibbous", "last quarter", "waning crescent"]
    body = []

    south = str(spec.get("hemisphere", "south")).lower().startswith("s")

    def disc(x, y, r, k):
        """Moon as seen from Earth at phase index k (0 new .. 4 full .. 7 waning crescent).

        In the Southern Hemisphere a waxing Moon is lit on the LEFT — the
        opposite of the textbook (Northern) pictures.
        """
        f = [0, .25, .5, .75, 1, .75, .5, .25][k]
        waxing = 1 <= k <= 3
        lit_right = (waxing != south)            # north+waxing -> right; south+waxing -> left
        dark, lit = "#2d3540", "#f4efd8"
        parts = [f'<circle cx="{x}" cy="{y}" r="{r}" fill="{dark}"/>']
        if f > 0:
            sweep = 1 if lit_right else 0
            parts.append(f'<path d="M{x},{y-r} A{r},{r} 0 0 {sweep} {x},{y+r} Z" fill="{lit}"/>')
            rx = r * abs(2 * f - 1)
            if rx > 0.5:
                parts.append(f'<ellipse cx="{x}" cy="{y}" rx="{rx:.1f}" ry="{r}" fill="{lit if f > 0.5 else dark}"/>')
        parts.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="{INK}" stroke-width="1.5"/>')
        return "".join(parts)

    if spec.get("all"):
        for k, name in enumerate(phases):
            x = 45 + k * 70
            body.append(disc(x, 50, 26, k))
            body.append(text(x, 100, name, 9.5, fill=INK2))
        body.append(text(300, 118, "as seen from Australia (Southern Hemisphere)" if south else "as seen from the Northern Hemisphere", 10, fill=INK3))
        return svg(600, 126, "".join(body), spec.get("caption"))

    name = spec.get("phase", "full").lower()
    if name not in phases:
        raise FigureError(f"unknown moon phase {name!r}; use one of {phases}")
    k = phases.index(name)
    # orbit view: Earth centre, Sun right, Moon at orbit position
    cx, cy = 170, 150
    body.append(f'<circle cx="{cx}" cy="{cy}" r="110" fill="none" stroke="{LINE}" stroke-dasharray="4 5"/>')
    body.append(f'<circle cx="{cx}" cy="{cy}" r="26" fill="{TEAL}"/>')
    body.append(text(cx, cy + 5, "Earth", 11, fill=CARD, weight="700"))
    body.append(f'<rect x="330" y="60" width="26" height="180" fill="{AMBER}" fill-opacity="0.85" rx="6"/>')
    body.append(text(343, 150 + 4, "☀", 20, fill=CARD))
    body.append(text(343, 256, "Sun's light", 11, fill=INK2))
    for i in range(6):
        y = 70 + i * 32
        body.append(f'<line x1="{cx+40}" y1="{y}" x2="326" y2="{y}" stroke="{AMBER}" stroke-width="1" stroke-opacity="0.5"/>')
    ang = math.radians(-k * 45)                   # new moon between Earth and Sun (right)
    mx, my = cx + 110 * math.cos(ang), cy - 110 * math.sin(ang)
    body.append(f'<circle cx="{mx:.1f}" cy="{my:.1f}" r="16" fill="#2d3540"/>')
    body.append(f'<path d="M{mx:.1f},{my-16:.1f} A16,16 0 0 1 {mx:.1f},{my+16:.1f} Z" fill="#f4efd8"/>')
    body.append(f'<circle cx="{mx:.1f}" cy="{my:.1f}" r="16" fill="none" stroke="{INK}" stroke-width="1.5"/>')
    # what we see
    body.append(text(470, 40, "Seen from Earth", 12, weight="700"))
    body.append(disc(470, 110, 44, k))
    body.append(text(470, 178, name, 13, weight="700", fill=INK2))
    body.append(text(470, 196, "from Australia" if south else "from the north", 10, fill=INK3))
    return svg(560, 300, "".join(body), spec.get("caption"))


def earth_tilt(spec):
    """{"month": "December"} — tilt fixed at 23.5°, Sun on the left, shows which hemisphere leans in."""
    month = str(spec.get("month", "December")).lower()
    summer_south = month[:3] in ("nov", "dec", "jan", "feb")
    tilt = -23.5 if summer_south else 23.5
    if month[:3] in ("mar", "sep"):
        tilt = 0
    cx, cy, r = 330, 150, 80
    body = [f'<circle cx="70" cy="{cy}" r="46" fill="{AMBER}"/>', text(70, cy + 5, "Sun", 13, fill=CARD, weight="700")]
    for i in range(7):
        y = cy - 72 + i * 24
        body.append(f'<line x1="122" y1="{y}" x2="{cx-r-6}" y2="{y}" stroke="{AMBER}" stroke-opacity="0.5"/>')
    body.append(f'<g transform="rotate({tilt} {cx} {cy})">')
    body.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{TEAL}"/>')
    body.append(f'<line x1="{cx}" y1="{cy-r-22}" x2="{cx}" y2="{cy+r+22}" stroke="{INK}" stroke-width="2" stroke-dasharray="6 4"/>')
    body.append(f'<line x1="{cx-r}" y1="{cy}" x2="{cx+r}" y2="{cy}" stroke="{CARD}" stroke-width="1.5"/>')
    body.append(text(cx, cy - r - 28, "N", 12, weight="700"))
    body.append(text(cx, cy + r + 38, "S", 12, weight="700"))
    body.append('</g>')
    # night side: the half facing away from the Sun (right half), un-rotated
    body.append(f'<path d="M{cx},{cy-r} A{r},{r} 0 0 1 {cx},{cy+r} Z" fill="#17212b" fill-opacity="0.45"/>')
    body.append(text(250, cy + r + 62, f"{spec.get('month', 'December')}: "
                     + ("Southern Hemisphere tilted toward the Sun" if summer_south else
                        "equinox — neither hemisphere tilted in" if tilt == 0 else
                        "Northern Hemisphere tilted toward the Sun"), 12, fill=INK2))
    return svg(500, 300, "".join(body), spec.get("caption"))


def water_cycle(spec):
    """Fixed diagram with labelled arrows. {"labels": true}"""
    body = [f'<rect x="0" y="0" width="520" height="260" fill="#eaf4fb" rx="8"/>',
            f'<path d="M0,200 Q120,120 260,180 T520,150 L520,260 L0,260 Z" fill="#c6d9a4"/>',
            f'<path d="M0,260 L0,215 Q90,205 180,225 T340,240 L340,260 Z" fill="#7fb3d5"/>',
            f'<circle cx="460" cy="48" r="26" fill="{AMBER}"/>',
            f'<ellipse cx="150" cy="60" rx="58" ry="24" fill="{CARD}" stroke="{INK3}"/>',
            f'<ellipse cx="200" cy="52" rx="40" ry="20" fill="{CARD}" stroke="{INK3}"/>',
            f'<ellipse cx="360" cy="75" rx="50" ry="22" fill="{CARD}" stroke="{INK3}"/>']
    # rain
    for i in range(6):
        x = 330 + i * 14
        body.append(f'<line x1="{x}" y1="100" x2="{x-6}" y2="122" stroke="#4a86b8" stroke-width="2"/>')
    # arrows: evaporation up from water, transpiration, wind, runoff
    arrow = f'stroke="{INK}" stroke-width="2.5" fill="none"'
    body.append(f'<path d="M110,210 C100,170 120,150 110,110" {arrow} marker-end="url(#wcA)"/>')
    body.append(f'<path d="M240,66 L300,70" {arrow} marker-end="url(#wcA)"/>')
    body.append(f'<path d="M380,140 C400,170 370,200 340,222" {arrow} marker-end="url(#wcA)"/>')
    body.insert(0, f'<defs><marker id="wcA" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="{INK}"/></marker></defs>')
    if spec.get("labels", True):
        body += [text(60, 150, "evaporation", 12, "start", weight="700"),
                 text(270, 40, "condensation", 12, weight="700"),
                 text(420, 130, "precipitation", 12, "start", weight="700"),
                 text(400, 205, "run-off", 12, "start", weight="700"),
                 text(60, 245, "ocean / river", 12, "start", fill=INK2)]
    return svg(520, 260, "".join(body), spec.get("caption"))


def raw_svg(spec):
    """{"type": "svg", "width": 300, "height": 200, "body": "<circle .../>"} — escape hatch."""
    w, h = int(_num(spec.get("width", 300), "width")), int(_num(spec.get("height", 200), "height"))
    body = spec.get("body", "")
    if "<script" in body.lower() or "onload" in body.lower() or "javascript:" in body.lower():
        raise FigureError("raw svg may not contain scripts")
    return svg(w, h, body, spec.get("caption"))


RENDERERS = {
    "fraction_bar": fraction_bar,
    "number_line": number_line,
    "area_grid": area_grid,
    "rectangle": rectangle,
    "bar_chart": bar_chart,
    "line_chart": line_chart,
    "picture_graph": picture_graph,
    "tally": tally,
    "table": table,
    "spinner": spinner,
    "angle": angle,
    "clock": clock,
    "thermometer": thermometer,
    "coins": coins,
    "cartesian": cartesian,
    "circuit": circuit,
    "food_chain": food_chain,
    "food_web": food_web,
    "moon_phases": moon_phases,
    "earth_tilt": earth_tilt,
    "water_cycle": water_cycle,
    "svg": raw_svg,
}


def render(spec):
    """Spec dict -> SVG markup (a <figure>). Raises FigureError on a bad spec."""
    if not isinstance(spec, dict):
        raise FigureError("figure must be an object")
    kind = spec.get("type")
    fn = RENDERERS.get(kind)
    if fn is None:
        raise FigureError(f"unknown figure type {kind!r}; known: {sorted(RENDERERS)}")
    return fn(spec)


def render_safe(spec):
    """For templates: never raise, show a small note instead."""
    try:
        return render(spec)
    except FigureError as exc:
        return f'<div class="figure-error">Figure could not be drawn: {esc(exc)}</div>'

# Figures and widgets — reference for content authors

A lesson **section** may carry `"figure": {...}` and/or `"widget": {...}`. A **question** may carry `"figure": {...}`.
Figures are drawn by the app from the spec below — you never write SVG. Every figure is
rendered by the validator, so a bad spec fails loudly.

Common optional key on every figure: `"caption": "short caption under the picture"`.

## Figure types

### `fraction_bar`

```
One or more bars split into equal parts with some shaded.

{"parts": 8, "shaded": 3, "label": "3/8"}
{"bars": [{"parts": 4, "shaded": 1, "label": "1/4"}, {"parts": 8, "shaded": 2, "label": "2/8"}]}
```

### `number_line`

```
{"min": 0, "max": 2, "step": 0.5, "marks": [{"at": 1.3, "label": "1.3"}], "range": [0.5, 1]}
```

### `area_grid`

```
{"width": 6, "height": 4, "unit": "m", "shade": 15}  (shade = number of squares to fill)
```

### `rectangle`

```
A labelled shape with dimension arrows. {"width": "12 m", "height": "5 m", "shape": "rectangle"}
```

### `bar_chart`

```
{"categories": [...], "values": [...], "unit": "mm", "grid": 50, "ymin": 0, "title": "...", "highlight": 2}

ymin > 0 draws a chopped axis (for the misleading-graph lessons).
```

### `line_chart`

```
{"x": ["Mon", ...], "series": [{"name": "Sun", "values": [...]}, ...], "unit": "°C", "grid": 5}
```

### `picture_graph`

```
{"symbol": "🥭", "each": 4, "rows": [{"label": "Mon", "count": 3.5}]}  count = number of symbols
```

### `tally`

```
{"rows": [{"label": "Cassowary", "count": 7}]}
```

### `table`

```
{"headers": ["Item", "Price"], "rows": [["Mango", "$2.50"], ...], "highlight": 1}
```

### `spinner`

```
{"sectors": [{"label": "red", "n": 3, "colour": "#c0402f"}, {"label": "blue", "n": 1}]}
```

### `angle`

```
{"degrees": 60, "protractor": true, "label": "?"}
```

### `clock`

```
{"time": "3:45", "digital": true}
```

### `thermometer`

```
{"min": -10, "max": 50, "value": 31, "unit": "°C", "step": 10}
```

### `coins`

```
Australian money laid out. {"items": [2, 1, 0.5, 0.2, 0.1, 0.05, 5, 10, 20, 50, 100]}
```

### `cartesian`

```
{"range": 5, "points": [{"x": 2, "y": -3, "label": "A"}], "quadrants": 4}
```

### `circuit`

```
{"bulbs": 2, "switch": "closed"|"open"|null, "battery": true, "broken": false, "series": true, "labels": true}

Draws a simple loop: battery on the left, bulbs along the top, optional switch on the right.
Bulbs are lit only if the loop is complete.
```

### `food_chain`

```
{"items": ["grass", "grasshopper", "frog", "snake"], "roles": ["producer", "consumer", ...]}
```

### `food_web`

```
{"nodes": ["sun","grass","wallaby","dingo","insects","frog"], "links": [["grass","wallaby"], ...]}
```

### `moon_phases`

```
{"phase": "first quarter"}  or  {"all": true}  — the Sun is off to the right.
```

### `earth_tilt`

```
{"month": "December"} — tilt fixed at 23.5°, Sun on the left, shows which hemisphere leans in.
```

### `water_cycle`

```
Fixed diagram with labelled arrows. {"labels": true}
```

### `svg`

```
{"type": "svg", "width": 300, "height": 200, "body": "<circle .../>"} — escape hatch.
```

## Widgets (interactive, sections only)

Each has an optional `title` (shown with a TRY IT tag) and `prompt` (a line under it telling the kid what to do).

```
{"type": "number_line", "title": "Find 1.3", "min": 0, "max": 2, "step": 0.5, "minor": 0.1, "snap": 0.1, "target": 1.3, "start": 0.4}
{"type": "protractor", "title": "Make a 60° angle", "target": 60, "start": 20}
{"type": "bar_reader", "title": "Rainfall", "categories": ["Nov","Dec"], "values": [50,150], "unit": "mm", "grid": 50, "ask": "Which month had 150 mm?"}
{"type": "circuit", "title": "Break the loop", "bulbs": 2, "switch": "closed"}
{"type": "fraction_shader", "title": "Shade 3/8", "parts": 8, "start": [0,1,2]}
{"type": "picture_key", "title": "Mango stall", "symbol": "🥭", "each": 4, "rows": [{"label": "Mon", "count": 12}], "keys": [1,2,4,10]}
```

`target` on number_line/protractor is optional — with it the widget coaches them toward the value; without it it just reads out.
Use at most one widget per lesson, in the section where doing it beats reading about it.
/* Quest Lab interactive widgets.
 *
 * A lesson section can carry {"widget": {"type": "number_line", ...}}; the
 * server renders <div class="widget" data-widget="number_line" data-spec="…">
 * and this file turns it into something the kid can play with. No libraries.
 *
 * Types: number_line, protractor, bar_reader, circuit, fraction_shader, picture_key
 */
(function () {
  "use strict";
  const NS = "http://www.w3.org/2000/svg";
  const css = (v, fb) => `var(${v}, ${fb})`;
  const INK = css("--ink", "#17212b"), INK2 = css("--ink-2", "#4a5b6b"), INK3 = css("--ink-3", "#7d8fa0");
  const LINE = css("--line", "#e3ded4"), TEAL = css("--teal", "#0f8a80"), TEAL_SOFT = css("--teal-soft", "#e2f2f0");
  const AMBER = css("--amber", "#c9761a"), VIOLET = css("--violet", "#6b52c9"), VIOLET_SOFT = css("--violet-soft", "#ece7fa");
  const CARD = css("--card", "#ffffff"), GREEN = css("--green", "#2f8f4e"), RED = css("--red", "#c0402f");

  function el(tag, attrs, parent) {
    const node = document.createElementNS(NS, tag);
    for (const k in attrs) node.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(node);
    return node;
  }
  function txt(x, y, s, attrs, parent) {
    const t = el("text", Object.assign({ x, y, "font-size": 13, "text-anchor": "middle", fill: INK }, attrs || {}), parent);
    t.textContent = s;
    return t;
  }
  function svgRoot(w, h) {
    const s = el("svg", { viewBox: `0 0 ${w} ${h}`, width: w, style: "max-width:100%;height:auto;touch-action:none;display:block",
      "font-family": "ui-sans-serif,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif" });
    return s;
  }
  function fmt(v, dp) { return Number(v).toFixed(dp).replace(/\.?0+$/, ""); }
  function readout(container, text) {
    let r = container.querySelector(".widget-readout");
    if (!r) { r = document.createElement("div"); r.className = "widget-readout"; container.appendChild(r); }
    r.textContent = text;
    return r;
  }
  function pointerPos(svg, evt) {
    const pt = svg.createSVGPoint();
    pt.x = evt.clientX; pt.y = evt.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  }
  function drag(svg, handle, onMove) {
    let active = false;
    const move = (e) => { if (!active) return; e.preventDefault(); onMove(pointerPos(svg, e)); };
    handle.addEventListener("pointerdown", (e) => { active = true; handle.setPointerCapture(e.pointerId); move(e); });
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", () => { active = false; });
    handle.addEventListener("pointercancel", () => { active = false; });
    // clicking anywhere on the svg also jumps there
    svg.addEventListener("pointerdown", (e) => { if (e.target === handle) return; onMove(pointerPos(svg, e)); });
  }

  /* ---------------- number line: drag a marker, read its value ---------------- */
  function numberLine(root, spec) {
    const lo = +spec.min || 0, hi = +spec.max || 10, step = +spec.step || 1, snap = +spec.snap || 0;
    const dp = spec.decimals != null ? +spec.decimals : (snap && snap < 1 ? String(snap).split(".")[1].length : 0);
    const W = 560, H = 110, pad = 34, y = 60;
    const svg = svgRoot(W, H);
    const X = (v) => pad + (v - lo) / (hi - lo) * (W - 2 * pad);
    const V = (x) => lo + (x - pad) / (W - 2 * pad) * (hi - lo);
    el("line", { x1: pad - 8, y1: y, x2: W - pad + 8, y2: y, stroke: INK, "stroke-width": 2 }, svg);
    if (spec.minor) for (let v = lo; v <= hi + 1e-9; v += +spec.minor)
      el("line", { x1: X(v), y1: y - 5, x2: X(v), y2: y + 5, stroke: INK3 }, svg);
    for (let v = lo, n = 0; v <= hi + 1e-9 && n < 200; v += step, n++) {
      el("line", { x1: X(v), y1: y - 10, x2: X(v), y2: y + 10, stroke: INK, "stroke-width": 2 }, svg);
      txt(X(v), y + 28, fmt(v, 3), { fill: INK2 }, svg);
    }
    let value = spec.start != null ? +spec.start : lo;
    const marker = el("g", { style: "cursor:grab" }, svg);
    const dot = el("circle", { cx: X(value), cy: y, r: 11, fill: AMBER, stroke: CARD, "stroke-width": 3 }, marker);
    const label = txt(X(value), y - 22, fmt(value, dp), { "font-size": 16, "font-weight": 700, fill: AMBER }, marker);
    const target = spec.target != null ? +spec.target : null;
    const hint = document.createElement("div");
    function set(v) {
      v = Math.max(lo, Math.min(hi, v));
      if (snap) v = Math.round(v / snap) * snap;
      value = v;
      dot.setAttribute("cx", X(v)); label.setAttribute("x", X(v)); label.textContent = fmt(v, dp);
      readout(root, target != null ? `Marker at ${fmt(v, dp)} — ${spec.ask || "find " + fmt(target, dp)}` : `Marker at ${fmt(v, dp)}`);
      if (target != null) {
        const ok = Math.abs(v - target) < (snap || 1e-9) / 2 + 1e-9;
        hint.textContent = ok ? "That's it." : (v < target ? "Further right." : "Back to the left.");
        hint.style.color = ok ? "var(--green)" : "var(--ink-3)";
      }
    }
    drag(svg, dot, (p) => set(V(p.x)));
    root.appendChild(svg); readout(root, ""); hint.className = "widget-prompt"; root.appendChild(hint);
    svg.setAttribute("tabindex", "0");
    svg.addEventListener("keydown", (e) => {
      const d = snap || step;
      if (e.key === "ArrowRight") { set(value + d); e.preventDefault(); }
      if (e.key === "ArrowLeft") { set(value - d); e.preventDefault(); }
    });
    set(value);
  }

  /* ---------------- protractor: rotate an arm, read the angle ---------------- */
  function protractor(root, spec) {
    const W = 460, H = 260, cx = 230, cy = 220, r = 180;
    const svg = svgRoot(W, H);
    el("path", { d: `M${cx - r},${cy} A${r},${r} 0 0 1 ${cx + r},${cy} Z`, fill: VIOLET_SOFT, stroke: INK2, "stroke-width": 1.5 }, svg);
    for (let d = 0; d <= 180; d += 5) {
      const a = Math.PI - d * Math.PI / 180, inner = r - (d % 30 === 0 ? 18 : d % 10 === 0 ? 11 : 6);
      el("line", { x1: cx + inner * Math.cos(a), y1: cy - inner * Math.sin(a), x2: cx + r * Math.cos(a), y2: cy - r * Math.sin(a),
        stroke: INK2, "stroke-width": d % 10 === 0 ? 1.2 : 0.7 }, svg);
      if (d % 30 === 0 && d !== 0 && d !== 180) txt(cx + (r - 30) * Math.cos(a), cy - (r - 30) * Math.sin(a) + 4, d, { "font-size": 11, fill: INK2 }, svg);
      if (d === 0 || d === 180) txt(cx + (r - 30) * Math.cos(a), cy - 10, d, { "font-size": 11, fill: INK2 }, svg);
    }
    el("line", { x1: cx, y1: cy, x2: cx + r - 20, y2: cy, stroke: INK, "stroke-width": 3, "stroke-linecap": "round" }, svg);
    const arc = el("path", { fill: "none", stroke: AMBER, "stroke-width": 3 }, svg);
    const arm = el("line", { x1: cx, y1: cy, stroke: INK, "stroke-width": 3, "stroke-linecap": "round" }, svg);
    const knob = el("circle", { r: 12, fill: AMBER, stroke: CARD, "stroke-width": 3, style: "cursor:grab" }, svg);
    const lab = txt(cx, cy - 40, "", { "font-size": 18, "font-weight": 700, fill: AMBER }, svg);
    el("circle", { cx, cy, r: 4, fill: INK }, svg);
    let deg = spec.start != null ? +spec.start : 45;
    const target = spec.target != null ? +spec.target : null;
    const hint = document.createElement("div");
    function set(d) {
      d = Math.max(0, Math.min(180, Math.round(d)));
      deg = d;
      const a = d * Math.PI / 180, len = r - 20;
      arm.setAttribute("x2", cx + len * Math.cos(a)); arm.setAttribute("y2", cy - len * Math.sin(a));
      knob.setAttribute("cx", cx + len * Math.cos(a)); knob.setAttribute("cy", cy - len * Math.sin(a));
      arc.setAttribute("d", `M${cx + 40},${cy} A40,40 0 ${d > 180 ? 1 : 0} 0 ${cx + 40 * Math.cos(a)},${cy - 40 * Math.sin(a)}`);
      lab.textContent = d + "°";
      const kind = d < 90 ? "acute" : d === 90 ? "a right angle" : d < 180 ? "obtuse" : "a straight angle";
      readout(root, `${d}° — ${kind}`);
      if (target != null) {
        hint.textContent = d === target ? "Spot on." : `${spec.ask || "Make " + target + "°"} (you're at ${d}°)`;
        hint.style.color = d === target ? "var(--green)" : "var(--ink-3)";
      }
    }
    drag(svg, knob, (p) => set(Math.atan2(cy - p.y, p.x - cx) * 180 / Math.PI));
    root.appendChild(svg); readout(root, ""); hint.className = "widget-prompt"; root.appendChild(hint);
    svg.setAttribute("tabindex", "0");
    svg.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight" || e.key === "ArrowDown") { set(deg - 1); e.preventDefault(); }
      if (e.key === "ArrowLeft" || e.key === "ArrowUp") { set(deg + 1); e.preventDefault(); }
    });
    set(deg);
  }

  /* ---------------- bar chart you read by hovering / tapping ---------------- */
  function barReader(root, spec) {
    const cats = spec.categories || [], vals = (spec.values || []).map(Number);
    const grid = +spec.grid || Math.ceil(Math.max(...vals) / 5), ymin = +spec.ymin || 0;
    const top = Math.ceil((spec.ymax ? +spec.ymax : Math.max(...vals) * 1.15) / grid) * grid;
    const W = 560, H = 320, L = 64, R = 20, T = spec.title ? 40 : 20, B = 50, pw = W - L - R, ph = H - T - B;
    const svg = svgRoot(W, H);
    const Y = (v) => T + ph - (v - ymin) / (top - ymin) * ph;
    if (spec.title) txt(L + pw / 2, 24, spec.title, { "font-size": 15, "font-weight": 700 }, svg);
    for (let v = ymin; v <= top + 1e-9; v += grid) {
      el("line", { x1: L, y1: Y(v), x2: L + pw, y2: Y(v), stroke: LINE }, svg);
      txt(L - 8, Y(v) + 4, fmt(v, 2), { "text-anchor": "end", "font-size": 12, fill: INK2 }, svg);
    }
    if (spec.unit) txt(14, 12, spec.unit, { "text-anchor": "start", "font-size": 12, fill: INK3 }, svg);
    const guide = el("line", { x1: L, x2: L + pw, stroke: AMBER, "stroke-width": 1.5, "stroke-dasharray": "4 4", opacity: 0 }, svg);
    const bw = pw / cats.length;
    const bars = cats.map((c, i) => {
      const x = L + i * bw + bw * 0.18, w = bw * 0.64;
      const bar = el("rect", { x, y: Y(vals[i]), width: w, height: T + ph - Y(vals[i]), fill: TEAL, rx: 3, style: "cursor:pointer" }, svg);
      txt(x + w / 2, T + ph + 20, c, { "font-size": 12, fill: INK2 }, svg);
      const show = () => {
        bars.forEach((b) => b.setAttribute("fill", TEAL)); bar.setAttribute("fill", AMBER);
        guide.setAttribute("y1", Y(vals[i])); guide.setAttribute("y2", Y(vals[i])); guide.setAttribute("opacity", 1);
        readout(root, `${c}: ${fmt(vals[i], 2)}${spec.unit ? " " + spec.unit : ""}`);
      };
      bar.addEventListener("pointerenter", show); bar.addEventListener("pointerdown", show);
      bar.addEventListener("focus", show); bar.setAttribute("tabindex", "0");
      return bar;
    });
    el("line", { x1: L, y1: T, x2: L, y2: T + ph, stroke: INK, "stroke-width": 1.5 }, svg);
    el("line", { x1: L, y1: T + ph, x2: L + pw, y2: T + ph, stroke: INK, "stroke-width": 1.5 }, svg);
    root.appendChild(svg);
    readout(root, spec.ask || "Hover or tap a bar to read it off the axis.");
  }

  /* ---------------- circuit: flick the switch, pull a wire ---------------- */
  function circuit(root, spec) {
    const n = Math.max(1, Math.min(3, +spec.bulbs || 1));
    const W = 460, H = 240, L = 60, R = 400, T = 50, B = 180;
    const svg = svgRoot(W, H);
    const state = { closed: spec.switch !== "open", wire: true, battery: spec.battery !== false };
    const stroke = { stroke: INK, "stroke-width": 3, fill: "none" };
    // battery
    el("line", Object.assign({ x1: L, y1: T, x2: L, y2: 105 }, stroke), svg);
    [[16, 105], [8, 115], [16, 125], [8, 135]].forEach(([w, y]) => el("line", Object.assign({ x1: L - w, y1: y, x2: L + w, y2: y }, stroke), svg));
    el("line", Object.assign({ x1: L, y1: 135, x2: L, y2: B }, stroke), svg);
    txt(L, B + 26, "battery", { "font-size": 11, fill: INK2 }, svg);
    // top wire + bulbs
    el("line", Object.assign({ x1: L, y1: T, x2: R, y2: T }, stroke), svg);
    const glows = [], bulbs = [];
    for (let i = 0; i < n; i++) {
      const x = L + (i + 1) * (R - L) / (n + 1);
      el("circle", { cx: x, cy: T, r: 16, fill: CARD }, svg);
      glows.push(el("circle", { cx: x, cy: T, r: 24, fill: AMBER, "fill-opacity": 0 }, svg));
      bulbs.push(el("circle", { cx: x, cy: T, r: 14, fill: CARD, stroke: INK, "stroke-width": 2 }, svg));
      el("path", { d: `M${x - 6},${T + 4} l4,-6 l4,6 l4,-6`, fill: "none", stroke: INK, "stroke-width": 1.5 }, svg);
    }
    // bottom wire, with a pull-apart section in the middle
    const mid = (L + R) / 2;
    el("line", Object.assign({ x1: L, y1: B, x2: mid - 30, y2: B }, stroke), svg);
    el("line", Object.assign({ x1: mid + 30, y1: B, x2: R, y2: B }, stroke), svg);
    const wire = el("line", Object.assign({ x1: mid - 30, y1: B, x2: mid + 30, y2: B, style: "cursor:pointer" }, stroke), svg);
    const wireHit = el("rect", { x: mid - 34, y: B - 14, width: 68, height: 28, fill: "transparent", style: "cursor:pointer" }, svg);
    const wireLab = txt(mid, B + 26, "wire (tap to pull apart)", { "font-size": 11, fill: INK2 }, svg);
    // switch
    el("line", Object.assign({ x1: R, y1: T, x2: R, y2: 95 }, stroke), svg);
    el("line", Object.assign({ x1: R, y1: 135, x2: R, y2: B }, stroke), svg);
    el("circle", { cx: R, cy: 95, r: 4, fill: INK }, svg); el("circle", { cx: R, cy: 135, r: 4, fill: INK }, svg);
    const blade = el("line", Object.assign({ x1: R, y1: 135, style: "cursor:pointer" }, stroke), svg);
    const swHit = el("rect", { x: R - 18, y: 88, width: 56, height: 56, fill: "transparent", style: "cursor:pointer" }, svg);
    const swLab = txt(R + 4, 124, "", { "text-anchor": "start", "font-size": 11 }, svg);
    function update() {
      const on = state.closed && state.wire && state.battery;
      bulbs.forEach((b) => b.setAttribute("fill", on ? "#ffd54a" : CARD));
      glows.forEach((g) => g.setAttribute("fill-opacity", on ? 0.25 : 0));
      blade.setAttribute("x2", state.closed ? R : R + 26); blade.setAttribute("y2", state.closed ? 95 : 103);
      swLab.textContent = state.closed ? "closed" : "open"; swLab.setAttribute("fill", state.closed ? GREEN : RED);
      wire.setAttribute("opacity", state.wire ? 1 : 0);
      wireLab.textContent = state.wire ? "wire (tap to pull apart)" : "gap (tap to reconnect)";
      readout(root, on ? `Circuit complete — ${n > 1 ? "the bulbs light" : "the bulb lights"}.`
        : !state.closed ? "Switch open — no complete loop, so no current flows."
        : "There's a gap in the wire — no complete loop, so no current flows.");
    }
    const toggleSwitch = () => { state.closed = !state.closed; update(); };
    const toggleWire = () => { state.wire = !state.wire; update(); };
    [blade, swHit].forEach((h) => h.addEventListener("pointerdown", toggleSwitch));
    [wire, wireHit].forEach((h) => h.addEventListener("pointerdown", toggleWire));
    root.appendChild(svg);
    const btns = document.createElement("div"); btns.className = "widget-buttons";
    const b1 = document.createElement("button"); b1.type = "button"; b1.textContent = "Flick the switch"; b1.onclick = toggleSwitch;
    const b2 = document.createElement("button"); b2.type = "button"; b2.textContent = "Break / fix the wire"; b2.onclick = toggleWire;
    btns.append(b1, b2); root.appendChild(btns);
    update();
  }

  /* ---------------- fraction shader: tap parts, see the fraction ---------------- */
  function fractionShader(root, spec) {
    let parts = Math.max(1, Math.min(24, +spec.parts || 8));
    const W = 560, H = 96, bw = 500, x0 = 30, y0 = 18, bh = 50;
    const svg = svgRoot(W, H);
    const shaded = new Set((spec.start || []).map(Number));
    const cells = [];
    function gcd(a, b) { return b ? gcd(b, a % b) : a; }
    function draw() {
      cells.forEach((c) => c.remove()); cells.length = 0;
      const pw = bw / parts;
      for (let i = 0; i < parts; i++) {
        const c = el("rect", { x: x0 + i * pw, y: y0, width: pw, height: bh, fill: shaded.has(i) ? TEAL : CARD, stroke: INK, "stroke-width": 1.5, style: "cursor:pointer", tabindex: 0 }, svg);
        c.addEventListener("pointerdown", () => { shaded.has(i) ? shaded.delete(i) : shaded.add(i); draw(); });
        cells.push(c);
      }
      const k = shaded.size, g = gcd(k, parts) || 1;
      const simple = k && g > 1 ? ` = ${k / g}/${parts / g}` : "";
      readout(root, `${k}/${parts} shaded${simple} = ${fmt(k / parts, 3)} = ${fmt(100 * k / parts, 1)}%`);
    }
    root.appendChild(svg);
    if (spec.allow_split !== false) {
      const btns = document.createElement("div"); btns.className = "widget-buttons";
      const b1 = document.createElement("button"); b1.type = "button"; b1.textContent = "Split into more parts";
      b1.onclick = () => { if (parts < 24) { const old = parts; parts = old * 2; const next = new Set(); shaded.forEach((i) => { next.add(i * 2); next.add(i * 2 + 1); }); shaded.clear(); next.forEach((i) => shaded.add(i)); draw(); } };
      const b2 = document.createElement("button"); b2.type = "button"; b2.textContent = "Clear";
      b2.onclick = () => { shaded.clear(); draw(); };
      btns.append(b1, b2); root.appendChild(btns);
    }
    draw();
  }

  /* ---------------- picture graph: change the key, watch the numbers ---------------- */
  function pictureKey(root, spec) {
    const rows = spec.rows || [], sym = spec.symbol || "●";
    let each = +spec.each || 1;
    const lw = 100, sw = 30, rh = 38;
    const maxN = Math.max(...rows.map((r) => +r.count));
    const W = lw + Math.ceil(maxN / 1) * sw + 90, H = 16 + rows.length * rh + 12;
    const svg = svgRoot(W, H);
    const dyn = [];
    function draw() {
      dyn.forEach((d) => d.remove()); dyn.length = 0;
      rows.forEach((r, i) => {
        const y = 16 + i * rh, n = +r.count / each;
        dyn.push(txt(lw - 12, y + 25, r.label, { "text-anchor": "end", "font-size": 14, "font-weight": 700 }, svg));
        let k = 0;
        for (; k < Math.floor(n); k++) { const t = txt(lw + k * sw, y + 27, sym, { "text-anchor": "start", "font-size": 22 }, svg); dyn.push(t); }
        const rem = n - Math.floor(n);
        if (rem > 0.01) {
          const cid = "pk" + i + Math.random().toString(36).slice(2, 6);
          const clip = el("clipPath", { id: cid }, svg); el("rect", { x: lw + k * sw, y, width: 26 * rem, height: rh }, clip);
          dyn.push(clip);
          dyn.push(txt(lw + k * sw, y + 27, sym, { "text-anchor": "start", "font-size": 22, "clip-path": `url(#${cid})` }, svg));
        }
        dyn.push(txt(W - 10, y + 25, `= ${r.count}`, { "text-anchor": "end", "font-size": 13, fill: INK2 }, svg));
        dyn.push(el("line", { x1: lw - 6, y1: y + rh - 4, x2: W - 8, y2: y + rh - 4, stroke: LINE }, svg));
      });
      readout(root, `Key: ${sym} = ${each}. ${spec.ask || "Change the key and watch how many pictures each row needs."}`);
    }
    root.appendChild(svg);
    const btns = document.createElement("div"); btns.className = "widget-buttons";
    (spec.keys || [1, 2, 5, 10]).forEach((k) => {
      const b = document.createElement("button"); b.type = "button"; b.textContent = `${sym} = ${k}`;
      b.onclick = () => { each = k; draw(); }; btns.appendChild(b);
    });
    root.appendChild(btns);
    draw();
  }

  const BUILDERS = { number_line: numberLine, protractor, bar_reader: barReader, circuit, fraction_shader: fractionShader, picture_key: pictureKey };

  function init() {
    document.querySelectorAll(".widget[data-widget]").forEach((root) => {
      if (root.dataset.ready) return;
      root.dataset.ready = "1";
      let spec = {};
      try { spec = JSON.parse(root.dataset.spec || "{}"); } catch (e) { /* ignore */ }
      const build = BUILDERS[root.dataset.widget];
      root.innerHTML = "";
      if (!build) { root.textContent = "Unknown widget: " + root.dataset.widget; return; }
      if (spec.title) { const h = document.createElement("div"); h.className = "widget-title"; h.textContent = spec.title; root.appendChild(h); }
      try { build(root, spec); } catch (e) { root.textContent = "This interactive part couldn't load."; console.error(e); }
      if (spec.prompt) { const p = document.createElement("div"); p.className = "widget-prompt"; p.textContent = spec.prompt; root.appendChild(p); }
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

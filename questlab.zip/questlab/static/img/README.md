# Your own artwork goes here

Drop a PNG in and the app uses it instead of the built-in line icon. Nothing else to change.

    static/img/subjects/maths.png        static/img/subjects/science.png     static/img/subjects/practical.png
    static/img/badges/<badge code>.png   e.g. badges/perfect.png, badges/boss_down.png

Badge codes: first_quiz, perfect, perfect_five, streak_3, streak_7, century, five_hundred,
maths_10, science_10, practical_10, all_rounder, stretch_10, level_5, hands_on, hands_on_10,
hands_on_all, challenger, boss_down, boss_all.

Square images, 256x256 or larger, transparent background works best. The app scales them.
